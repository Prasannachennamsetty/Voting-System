const adminAddress = '0x92a8709cc02a9c7F9ed8ACf14FCB795332637c0b'; // Replace with actual admin address
const contractAddress = '0x97ac4e43805D0F29e2874265a1fa484a189B9C60'; // Replace with your deployed contract address
const abi = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			}
		],
		"name": "addCandidate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_admin",
				"type": "address"
			}
		],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "newAdmin",
				"type": "address"
			}
		],
		"name": "AdminTransferred",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "name",
				"type": "string"
			}
		],
		"name": "CandidateAdded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			}
		],
		"name": "CandidateDeleted",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "declareWinner",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "deleteCandidate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "endVoting",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "startVoting",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "newAdmin",
				"type": "address"
			}
		],
		"name": "transferOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "vote",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "voter",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "candidateId",
				"type": "uint256"
			}
		],
		"name": "Voted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [],
		"name": "VotingEnded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [],
		"name": "VotingStarted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "winnerId",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "winnerName",
				"type": "string"
			}
		],
		"name": "WinnerDeclared",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "candidates",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "voteCount",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "exists",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "candidatesCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "getCandidate",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getCandidatesCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "voters",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "votingActive",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "votingEnded",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];

let web3;
let contract;
let accounts;

// Connect Wallet
document.getElementById('connect-wallet').addEventListener('click', async () => {
    if (window.ethereum) {
        try {
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            web3 = new Web3(window.ethereum);
            accounts = await web3.eth.getAccounts();
            document.getElementById('wallet-address').textContent = accounts[0];
            contract = new web3.eth.Contract(abi, contractAddress);
            populateAccountDropdown(accounts);
            initializePage();
        } catch (error) {
            console.error("Error connecting wallet:", error);
            alert("Failed to connect wallet. Please check the console for details.");
        }
    } else {
        alert("Please install MetaMask to use this app.");
    }
});

// Populate Account Dropdown
const populateAccountDropdown = (accounts) => {
    const accountDropdown = document.getElementById('accounts');
    accountDropdown.innerHTML = '';
    accounts.forEach(account => {
        const option = document.createElement('option');
        option.value = account;
        option.textContent = account;
        accountDropdown.appendChild(option);
    });
    document.getElementById('account-dropdown').style.display = 'block';

    // Add event listener to the dropdown
    accountDropdown.addEventListener('change', async (event) => {
        const selectedAccount = event.target.value;
        updateConnectedWallet(selectedAccount);
    });
};

// Update Connected Wallet Address
const updateConnectedWallet = (selectedAccount) => {
    document.getElementById('wallet-address').textContent = selectedAccount;
    accounts = [selectedAccount]; // Update the accounts array with the selected account
    initializePage(); // Reinitialize the page with the new account
};

// Handle Account Changes in MetaMask
if (window.ethereum) {
    window.ethereum.on('accountsChanged', (newAccounts) => {
        accounts = newAccounts;
        document.getElementById('wallet-address').textContent = accounts[0];
        populateAccountDropdown(accounts);
        initializePage();
    });
}

// Initialize Page Based on Role (Admin/User)
const initializePage = async () => {
    if (accounts[0].toLowerCase() === adminAddress.toLowerCase()) {
        document.getElementById('admin-dashboard').style.display = 'block';
        document.getElementById('user-dashboard').style.display = 'none';
        await loadCandidates();
    } else {
        document.getElementById('admin-dashboard').style.display = 'none';
        document.getElementById('user-dashboard').style.display = 'block';
        await loadCandidates();
    }
};

// Load Candidates for Both Admin and User
const loadCandidates = async () => {
    try {
        const candidatesCount = await contract.methods.getCandidatesCount().call();
        const tableBody = document.querySelector(
            accounts[0].toLowerCase() === adminAddress.toLowerCase()
                ? '#candidates-table tbody'
                : '#user-candidates-table tbody'
        );
        tableBody.innerHTML = '';
        for (let i = 1; i <= candidatesCount; i++) {
            const candidate = await contract.methods.getCandidate(i).call();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${candidate[0]}</td>
                <td>${candidate[1]}</td>
                <td>
                    ${
                        accounts[0].toLowerCase() === adminAddress.toLowerCase()
                            ? `<button onclick="deleteCandidate(${i})">Delete</button>`
                            : `<button onclick="vote(${i})">Vote</button>`
                    }
                </td>
            `;
            tableBody.appendChild(row);
        }
    } catch (error) {
        console.error("Error loading candidates:", error);
    }
};

// Add a Candidate
const addCandidate = async () => {
    const candidateName = document.getElementById('new-candidate-name').value;
    if (!candidateName) {
        alert("Candidate name cannot be empty");
        return;
    }
    try {
        // Send the transaction to add a candidate
        const receipt = await contract.methods.addCandidate(candidateName).send({ from: accounts[0] });
        console.log("Transaction receipt:", receipt);

        // Refresh the candidate list
        await loadCandidates();

        // Clear the input field
        document.getElementById('new-candidate-name').value = '';

        alert("Candidate added successfully!");
    } catch (error) {
        console.error("Error adding candidate:", error);
        alert("Failed to add candidate. Please check the console for details.");
    }
};

// Delete a Candidate
const deleteCandidate = async (candidateId) => {
    try {
        await contract.methods.deleteCandidate(candidateId).send({ from: accounts[0] });
        alert("Candidate deleted!");
        await loadCandidates();
    } catch (error) {
        console.error("Error deleting candidate:", error);
        alert("Failed to delete candidate. Please check the console for details.");
    }
};

// Vote for a Candidate
const vote = async (candidateId) => {
    try {
        await contract.methods.vote(candidateId).send({ from: accounts[0] });
        alert("Vote successful!");
        await loadCandidates();
    } catch (error) {
        console.error("Error voting:", error);
        alert("Failed to vote. Please check the console for details.");
    }
};

// Start Voting
const startVoting = async () => {
    try {
        await contract.methods.startVoting().send({ from: accounts[0] });
        alert("Voting started!");
    } catch (error) {
        console.error("Error starting voting:", error);
        alert("Failed to start voting. Please check the console for details.");
    }
};

// End Voting
const endVoting = async () => {
    try {
        await contract.methods.endVoting().send({ from: accounts[0] });
        alert("Voting ended!");
    } catch (error) {
        console.error("Error ending voting:", error);
        alert("Failed to end voting. Please check the console for details.");
    }
};

// Declare Winner
// Declare Winner
const declareWinner = async () => {
    try {
        const candidatesCount = await contract.methods.getCandidatesCount().call();
        let maxVotes = 0;
        let winnerId = 0;
        let winnerName = '';

        // Iterate through all candidates to find the one with the highest votes
        for (let i = 1; i <= candidatesCount; i++) {
            const candidate = await contract.methods.getCandidate(i).call();
            const candidateVotes = candidate[1]; // Vote count is at index 1

            if (candidateVotes > maxVotes) {
                maxVotes = candidateVotes;
                winnerId = i;
                winnerName = candidate[0]; // Candidate name is at index 0
            }
        }

        if (winnerId === 0) {
            alert("No candidates found or no votes cast.");
            return;
        }

        // Display the winner
        document.getElementById('winner-name').textContent = winnerName;
        document.getElementById('winner-votes').textContent = maxVotes;
        document.getElementById('winner').style.display = 'block';

        alert(`Winner declared: ${winnerName} with ${maxVotes} votes!`);
    } catch (error) {
        console.error("Error declaring winner:", error);
        alert("Failed to declare winner. Please check the console for details.");
    }
};